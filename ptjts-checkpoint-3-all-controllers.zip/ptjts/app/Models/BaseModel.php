<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model as EloquentModel;

/**
 * Base Model untuk seluruh model aplikasi JTS.
 *
 * Menetapkan koneksi database default ke 'pgsql' (Supabase Postgres via
 * connection pooler), karena Laravel secara default akan memakai koneksi
 * 'default' dari config/database.php — namun dideklarasikan eksplisit di
 * sini agar jelas dan mudah di-override saat testing (sqlite_testing).
 */
abstract class BaseModel extends EloquentModel
{
    /**
     * @var string
     */
    protected $connection = 'pgsql';
}
