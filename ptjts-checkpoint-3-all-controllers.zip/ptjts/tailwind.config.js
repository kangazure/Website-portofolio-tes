/** @type {import('tailwindcss').Config} */
export default {
    darkMode: 'class',
    content: [
        './resources/views/**/*.blade.php',
        './resources/js/**/*.{ts,js}',
        './resources/scss/**/*.scss',
    ],
    safelist: [
        'aos-init',
        'aos-animate',
        { pattern: /^data-aos/ },
    ],
    theme: {
        extend: {
            colors: {
                brand: {
                    DEFAULT: '#ff6600',
                    50: '#fff4ec',
                    100: '#ffe5d1',
                    200: '#ffc7a3',
                    300: '#ffa066',
                    400: '#ff8533',
                    500: '#ff6600',
                    600: '#db5300',
                    700: '#b34300',
                    800: '#8a3400',
                    900: '#662700',
                    950: '#3d1700',
                },
                ink: {
                    DEFAULT: '#0a0a0a',
                    50: '#f7f7f7',
                    100: '#e3e3e3',
                    200: '#c8c8c8',
                    300: '#a4a4a4',
                    400: '#818181',
                    500: '#666666',
                    600: '#515151',
                    700: '#434343',
                    800: '#262626',
                    900: '#161616',
                    950: '#0a0a0a',
                },
                surface: {
                    light: '#ffffff',
                    soft: '#f5f5f7',
                    dark: '#0d0d0f',
                    darksoft: '#15151a',
                },
            },
            fontFamily: {
                sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
                display: ['"Clash Display"', '"Plus Jakarta Sans"', 'sans-serif'],
                mono: ['"JetBrains Mono"', 'monospace'],
            },
            backgroundImage: {
                'grid-pattern': 'linear-gradient(rgba(255,102,0,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,102,0,0.08) 1px, transparent 1px)',
                'radial-glow': 'radial-gradient(circle at center, rgba(255,102,0,0.25), transparent 70%)',
                'hero-gradient': 'linear-gradient(135deg, #0a0a0a 0%, #1a1208 45%, #2b1503 100%)',
            },
            backdropBlur: {
                xs: '2px',
            },
            boxShadow: {
                glow: '0 0 40px rgba(255,102,0,0.35)',
                'glow-lg': '0 0 80px rgba(255,102,0,0.45)',
                glass: '0 8px 32px rgba(0,0,0,0.25)',
                'inner-glass': 'inset 0 1px 0 rgba(255,255,255,0.08)',
            },
            animation: {
                'float': 'float 6s ease-in-out infinite',
                'pulse-glow': 'pulseGlow 3s ease-in-out infinite',
                'gradient-shift': 'gradientShift 8s ease infinite',
                'marquee': 'marquee 30s linear infinite',
                'fade-up': 'fadeUp 0.8s ease forwards',
            },
            keyframes: {
                float: {
                    '0%, 100%': { transform: 'translateY(0px)' },
                    '50%': { transform: 'translateY(-18px)' },
                },
                pulseGlow: {
                    '0%, 100%': { opacity: 0.4, transform: 'scale(1)' },
                    '50%': { opacity: 0.9, transform: 'scale(1.05)' },
                },
                gradientShift: {
                    '0%, 100%': { backgroundPosition: '0% 50%' },
                    '50%': { backgroundPosition: '100% 50%' },
                },
                marquee: {
                    '0%': { transform: 'translateX(0)' },
                    '100%': { transform: 'translateX(-50%)' },
                },
                fadeUp: {
                    '0%': { opacity: 0, transform: 'translateY(40px)' },
                    '100%': { opacity: 1, transform: 'translateY(0)' },
                },
            },
            backdropSaturate: {
                150: '1.5',
            },
            transitionTimingFunction: {
                'expo-out': 'cubic-bezier(0.16, 1, 0.3, 1)',
            },
        },
    },
    plugins: [
        require('@tailwindcss/forms'),
        require('@tailwindcss/typography'),
    ],
};
